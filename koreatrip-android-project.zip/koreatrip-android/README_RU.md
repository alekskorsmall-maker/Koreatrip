# KoreaTrip для Android — инструкция на русском

Это Android-приложение открывает сайт KoreaTrip в удобном полноэкранном окне, поддерживает переходы назад, открывает внешние ссылки (например, WhatsApp и Instagram) во внешних приложениях и показывает кнопку повтора при проблеме с интернетом.

## Важно перед публикацией

1. Сайт `https://koreatrip.ru/` должен открываться без ошибки 404 и иметь корректный HTTPS.
2. Google Play может отклонить приложение, которое является только оболочкой сайта без достаточной самостоятельной функциональности. Перед публикацией проверьте требования Play Console и добавьте полезные функции, если они нужны.
3. `applicationId` сейчас `ru.koreatrip.app`. После первой публикации его нельзя менять, если вы хотите выпускать обновления этого же приложения.
4. Никогда не теряйте файл keystore и пароли: без того же ключа нельзя выпускать обычные обновления приложения (если не настроен Play App Signing по правилам Google).

## Добавление проекта в GitHub с телефона

1. Откройте репозиторий `https://github.com/Alekskorsmall-maker/Koreatrip`.
2. Нажмите **Add file → Upload files**.
3. Распакуйте этот ZIP на телефоне и загрузите содержимое папки `koreatrip-android` в корень репозитория, сохранив структуру: папки `app`, `.github/workflows` и файлы `build.gradle`, `settings.gradle`, `gradle.properties`.
4. Нажмите **Commit changes**. В Actions должен появиться workflow `Build KoreaTrip Android release`.

Если GitHub на телефоне не показывает скрытую папку `.github`, включите отображение скрытых файлов в файловом менеджере или добавьте workflow отдельным файлом через GitHub: `.github/workflows/android-release.yml`.

## Подпись для Google Play

Для публикации нужен собственный Android keystore. Надёжнее создать его на компьютере с Android Studio/Java командой:

```bash
keytool -genkeypair -v -keystore koreatrip-release.jks -alias koreatrip -keyalg RSA -keysize 2048 -validity 10000
```

Сохраните файл `.jks`, пароль хранилища, alias и пароль ключа в безопасном месте. Не загружайте `.jks` в открытый репозиторий.

Создайте GitHub Actions secrets в **Settings → Secrets and variables → Actions → New repository secret**:

- `KEYSTORE_BASE64` — Base64 всего файла keystore (на компьютере: `base64 -w 0 koreatrip-release.jks`; на Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes('koreatrip-release.jks'))`).
- `KEYSTORE_PASSWORD` — пароль хранилища.
- `KEY_ALIAS` — alias, например `koreatrip`.
- `KEY_PASSWORD` — пароль ключа.

После добавления secrets откройте **Actions → Build KoreaTrip Android release → Run workflow**. После успешного запуска откройте результат и скачайте артефакт `KoreaTrip-Android-AAB`. Для Play Console нужен подписанный `.aab`.

## Сборка без подписи

Если secrets не добавлены, workflow соберёт диагностический неподписанный AAB. Его нельзя загружать как релиз в Google Play; добавьте secrets и запустите workflow ещё раз.
