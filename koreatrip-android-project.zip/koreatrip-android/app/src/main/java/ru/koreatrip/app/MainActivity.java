package ru.koreatrip.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.content.Intent;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.Context;
import android.view.View;
import android.view.Gravity;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://koreatrip.ru/";
    private static final String FALLBACK_URL = "https://alekskorsmall-maker.github.io/Koreatrip/";
    private WebView webView;
    private LinearLayout errorPanel;
    private TextView statusText;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(248,245,252));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                errorPanel.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView view, String url) {
                errorPanel.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showError("Не удалось загрузить KoreaTrip. Проверьте интернет и попробуйте ещё раз.");
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        errorPanel = new LinearLayout(this);
        errorPanel.setOrientation(LinearLayout.VERTICAL);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(36, 36, 36, 36);
        errorPanel.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this);
        title.setText("KoreaTrip"); title.setTextSize(28); title.setTextColor(Color.rgb(35,35,45)); title.setGravity(Gravity.CENTER);
        errorPanel.addView(title, new LinearLayout.LayoutParams(-1, -2));
        statusText = new TextView(this); statusText.setTextSize(16); statusText.setTextColor(Color.DKGRAY); statusText.setGravity(Gravity.CENTER); statusText.setPadding(0, 18, 0, 20);
        errorPanel.addView(statusText, new LinearLayout.LayoutParams(-1, -2));
        Button retry = new Button(this); retry.setText("Повторить"); retry.setOnClickListener(v -> loadHome());
        errorPanel.addView(retry, new LinearLayout.LayoutParams(-2, -2));
        root.addView(errorPanel, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (state != null) webView.restoreState(state); else loadHome();
    }

    private void loadHome() {
        errorPanel.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE);
        if (!isOnline()) { showError("Нет подключения к интернету. Подключитесь и нажмите «Повторить»."); return; }
        webView.loadUrl(HOME_URL);
    }
    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null || cm.getActiveNetwork() == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }
    private void showError(String message) {
        webView.setVisibility(View.GONE); errorPanel.setVisibility(View.VISIBLE); statusText.setText(message);
    }
    private boolean handleUrl(String raw) {
        Uri uri = Uri.parse(raw); String scheme = uri.getScheme() == null ? "" : uri.getScheme(); String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        if (scheme.equals("http") || scheme.equals("https")) {
            if (host.equals("koreatrip.ru") || host.equals("www.koreatrip.ru") || host.equals("aleks-korsmall-maker.github.io")) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
            return true;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
        return true;
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.getVisibility() == View.VISIBLE && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (webView != null) webView.saveState(out); }
    @Override protected void onDestroy() { if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
