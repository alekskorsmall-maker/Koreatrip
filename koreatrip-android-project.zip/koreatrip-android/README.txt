KoreaTrip Android WebView project
Application ID: ru.koreatrip.app
Start URL: https://koreatrip.ru/
Build with Gradle 8.9 and Android SDK 35.
