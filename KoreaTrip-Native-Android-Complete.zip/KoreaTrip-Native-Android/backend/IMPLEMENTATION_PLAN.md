# Implementation plan

## Phase 1 — native app foundation (included)
- Kotlin + Jetpack Compose app, no WebView.
- RU/KO/EN language switch.
- Home, travel services, store, cart, demo orders, profile screens.
- Native Android project scaffold and initial SQL schema.

## Phase 2 — hosted backend
- Create Supabase project and configure Android build secrets.
- Add Auth and profiles; persistent session and language preference.
- Add repositories for products/services/orders.
- Implement order creation with a Supabase Edge Function that validates all inputs and computes totals server-side.
- Add image storage and product image loading.
- Add admin role and audit trail.

## Phase 3 — administration
- Protected admin dashboard for products, service catalog, prices, inventory, order status, and customer inquiries.
- Role-based access enforced by backend RLS/Edge Functions.
- Notifications when order status changes.

## Phase 4 — live travel services
- Confirm providers/affiliate APIs for flights, ferries, and hotels.
- K-ETA workflow must remain assistance/information unless an authorized official integration exists; no promise of approval.
- Availability, prices, cancellation rules, taxes, and terms displayed before confirmation.

## Phase 5 — commerce and release
- Select payment provider after merchant/business eligibility review.
- Payment webhooks, refunds, order reconciliation, and fraud controls.
- Privacy policy, terms, support channel, account deletion, Play Data Safety declaration.
- Automated tests, physical-device testing, signed release AAB, Play Console internal testing.

## Release gates
- Never store Supabase service-role secrets in the APK.
- No live payments until server verification and refund flow are tested.
- No production bookings until provider contracts/API and cancellation policies are confirmed.
