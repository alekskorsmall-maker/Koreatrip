package ru.koreatrip.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF13233F)
private val Blue = Color(0xFF356AE6)
private val Pale = Color(0xFFF4F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KoreaTripApp() }
    }
}

enum class Lang { RU, KO, EN }
enum class Tab { HOME, TRAVEL, SHOP, ORDERS, PROFILE }

data class CatalogItem(val title: String, val subtitle: String, val price: String, val category: String)
data class TravelService(val title: String, val detail: String, val price: String)

@Composable
fun KoreaTripApp() {
    var lang by remember { mutableStateOf(Lang.RU) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var selectedCategory by remember { mutableStateOf("all") }
    var cart by remember { mutableStateOf(listOf<CatalogItem>()) }
    var orders by remember { mutableStateOf(listOf<String>()) }
    var notice by remember { mutableStateOf("") }
    val products = demoProducts()
    val services = demoServices()

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy, background = Pale)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBarKorea(
                    lang = lang,
                    onLang = { lang = it },
                    title = when(tab) {
                        Tab.HOME -> tr(lang, "Путешествуйте по Корее", "한국 여행을 시작하세요", "Explore Korea")
                        Tab.TRAVEL -> tr(lang, "Услуги для поездки", "여행 서비스", "Travel services")
                        Tab.SHOP -> tr(lang, "Магазин", "스토어", "Shop")
                        Tab.ORDERS -> tr(lang, "Мои заказы", "내 주문", "My orders")
                        Tab.PROFILE -> tr(lang, "Личный кабинет", "내 계정", "Account")
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val navs = listOf(
                        Triple(Tab.HOME, Icons.Default.Home, tr(lang,"Главная","홈","Home")),
                        Triple(Tab.TRAVEL, Icons.Default.FlightTakeoff, tr(lang,"Поездка","여행","Travel")),
                        Triple(Tab.SHOP, Icons.Default.ShoppingBag, tr(lang,"Магазин","스토어","Shop")),
                        Triple(Tab.ORDERS, Icons.Default.ReceiptLong, tr(lang,"Заказы","주문","Orders")),
                        Triple(Tab.PROFILE, Icons.Default.Person, tr(lang,"Профиль","프로필","Profile"))
                    )
                    navs.forEach { (key, icon, label) ->
                        NavigationBarItem(
                            selected = tab == key,
                            onClick = { tab = key },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            },
            snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when(tab) {
                    Tab.HOME -> HomeScreen(lang, onTravel = { tab = Tab.TRAVEL }, onShop = { tab = Tab.SHOP })
                    Tab.TRAVEL -> TravelScreen(lang, services, onRequest = { service ->
                        orders = orders + "${service.title} • ${tr(lang,"Запрос создан","요청 생성됨","Request created")}"
                        notice = tr(lang, "Заявка добавлена в демо-заказы: ${service.title}", "데모 주문에 요청이 추가되었습니다: ${service.title}", "Demo request added: ${service.title}")
                        tab = Tab.ORDERS
                    })
                    Tab.SHOP -> ShopScreen(lang, products, selectedCategory, { selectedCategory = it }, { item ->
                        cart = cart + item
                        notice = tr(lang,"Добавлено в корзину: ${item.title}","장바구니에 추가됨: ${item.title}","Added to cart: ${item.title}")
                    }, onCheckout = {
                        if (cart.isNotEmpty()) {
                            orders = orders + "${tr(lang,"Заказ магазина","스토어 주문","Shop order")}: ${cart.joinToString { it.title }}"
                            cart = emptyList()
                            tab = Tab.ORDERS
                        }
                    }, cartCount = cart.size)
                    Tab.ORDERS -> OrdersScreen(lang, orders)
                    Tab.PROFILE -> ProfileScreen(lang)
                }
                if (notice.isNotBlank()) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp).fillMaxWidth()
                            .clickable { notice = "" },
                        color = Navy, shape = RoundedCornerShape(14.dp), shadowElevation = 6.dp
                    ) {
                        Text(notice + "  ×", color = Color.White, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarKorea(lang: Lang, onLang: (Lang)->Unit, title: String) {
    TopAppBar(
        title = { Column {
            Text("KoreaTrip", color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Text(title, color = Color.Gray, fontSize = 12.sp)
        }},
        actions = {
            var expanded by remember { mutableStateOf(false) }
            TextButton(onClick = { expanded = true }) { Text(lang.name, fontWeight = FontWeight.Bold) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                listOf(Lang.RU, Lang.KO, Lang.EN).forEach {
                    DropdownMenuItem(text = { Text(when(it){Lang.RU->"Русский";Lang.KO->"한국어";Lang.EN->"English"}) },
                        onClick = { onLang(it); expanded = false })
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
    )
}

@Composable
fun HomeScreen(lang: Lang, onTravel: ()->Unit, onShop: ()->Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Navy, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(tr(lang,"Южная Корея ближе, чем кажется","한국을 더 가깝게","Korea is closer than you think"),
                        color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(tr(lang,"Поездки, услуги и товары — в одном приложении","여행, 서비스, 상품을 한 곳에서","Trips, services and shopping in one app"),
                        color = Color(0xFFD8E3FF), fontSize = 14.sp)
                    Button(onClick = onTravel, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                        Text(tr(lang,"Подобрать поездку","여행 찾기","Plan a trip"))
                    }
                }
            }
        }
        item { Text(tr(lang,"Что вам нужно?","무엇이 필요하세요?","What do you need?"), fontSize=20.sp, fontWeight=FontWeight.Bold, color=Navy) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeTile("✈️", tr(lang,"Путешествия","여행","Travel"), tr(lang,"Отели и маршруты","호텔과 일정","Hotels & itineraries"), Modifier.weight(1f), onTravel)
                HomeTile("🛍️", tr(lang,"Магазин","스토어","Shop"), tr(lang,"Техника и косметика","전자제품과 화장품","Tech & beauty"), Modifier.weight(1f), onShop)
            }
        }
        item {
            Surface(shape=RoundedCornerShape(18.dp), color=Color.White, modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr(lang,"Скоро в Корее?","한국 여행 예정인가요?","Coming to Korea?"), fontWeight=FontWeight.Bold, fontSize=18.sp, color=Navy)
                    Spacer(Modifier.height(6.dp))
                    Text(tr(lang,"Соберите поездку: документы, транспорт, отель и план путешествия.",
                        "서류, 교통, 숙소, 여행 일정을 준비하세요.",
                        "Organize documents, transport, accommodation and itinerary."), color=Color.Gray)
                    TextButton(onClick=onTravel) { Text(tr(lang,"Посмотреть услуги →","서비스 보기 →","Explore services →")) }
                }
            }
        }
    }
}

@Composable
fun HomeTile(emoji: String, title: String, subtitle: String, modifier: Modifier, onClick: ()->Unit) {
    Surface(modifier=modifier.clickable(onClick=onClick), shape=RoundedCornerShape(18.dp), color=Color.White, shadowElevation=1.dp) {
        Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text(emoji, fontSize=28.sp)
            Text(title, fontWeight=FontWeight.Bold, color=Navy)
            Text(subtitle, color=Color.Gray, fontSize=12.sp)
        }
    }
}

@Composable
fun TravelScreen(lang: Lang, services: List<TravelService>, onRequest: (TravelService)->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text(tr(lang,"Выберите услугу. Заявка появится в разделе «Заказы».","서비스를 선택하세요. 요청은 주문에 표시됩니다.","Choose a service. Requests appear in Orders."),
            color=Color.Gray, fontSize=13.sp) }
        items(services) { service ->
            Surface(shape=RoundedCornerShape(18.dp), color=Color.White, shadowElevation=1.dp, modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text(service.title, color=Navy, fontWeight=FontWeight.Bold, fontSize=17.sp)
                    Text(service.detail, color=Color.Gray)
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text(service.price, color=Blue, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                        Button(onClick={onRequest(service)}) { Text(tr(lang,"Оставить заявку","요청하기","Request")) }
                    }
                }
            }
        }
    }
}

@Composable
fun ShopScreen(lang: Lang, products: List<CatalogItem>, category: String, onCategory: (String)->Unit, onAdd: (CatalogItem)->Unit, onCheckout: ()->Unit, cartCount: Int) {
    val filtered = products.filter { category == "all" || it.category == category }
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("all" to tr(lang,"Все","전체","All"), "tech" to tr(lang,"Электроника","전자제품","Tech"), "beauty" to tr(lang,"Косметика","화장품","Beauty")).forEach { (key,label) ->
                FilterChip(selected=category==key, onClick={onCategory(key)}, label={Text(label)})
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick=onCheckout, enabled=cartCount>0) { Text("🛒 $cartCount") }
        }
        LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(filtered) { item ->
                Surface(shape=RoundedCornerShape(16.dp), color=Color.White, modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(12.dp), color=Pale) {
                            Text(if(item.category=="tech") "📱" else "🧴", fontSize=28.sp, modifier=Modifier.padding(13.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color=Navy, fontWeight=FontWeight.Bold)
                            Text(item.subtitle, color=Color.Gray, fontSize=12.sp)
                            Text(item.price, color=Blue, fontWeight=FontWeight.Bold)
                        }
                        IconButton(onClick={onAdd(item)}) { Icon(Icons.Default.AddShoppingCart, contentDescription="Add to cart", tint=Blue) }
                    }
                }
            }
        }
    }
}

@Composable
fun OrdersScreen(lang: Lang, orders: List<String>) {
    if (orders.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
            Icon(Icons.Default.ReceiptLong, contentDescription=null, tint=Blue, modifier=Modifier.size(54.dp))
            Spacer(Modifier.height(12.dp))
            Text(tr(lang,"Пока нет заказов","아직 주문이 없습니다","No orders yet"), fontWeight=FontWeight.Bold, fontSize=20.sp, color=Navy)
            Text(tr(lang,"Создайте заявку на услугу или добавьте товары в корзину.","서비스 요청을 만들거나 상품을 장바구니에 담으세요.","Create a service request or add products to your cart."), color=Color.Gray)
        }
    } else {
        LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(orders.reversed()) { order ->
                Surface(shape=RoundedCornerShape(16.dp), color=Color.White, modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.ReceiptLong, contentDescription=null, tint=Blue)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(order, color=Navy, fontWeight=FontWeight.SemiBold)
                            Text(tr(lang,"Статус: черновик (демо)","상태: 임시 (데모)","Status: draft (demo)"), color=Color.Gray, fontSize=12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(lang: Lang) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Surface(shape=RoundedCornerShape(20.dp), color=Color.White, modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.AccountCircle, contentDescription=null, tint=Blue, modifier=Modifier.size(48.dp))
                    Text(tr(lang,"Ваш профиль","내 프로필","Your profile"), fontWeight=FontWeight.Bold, fontSize=20.sp, color=Navy)
                    OutlinedTextField(value=name, onValueChange={name=it}, label={Text(tr(lang,"Имя","이름","Name"))}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    OutlinedTextField(value=email, onValueChange={email=it}, label={Text(tr(lang,"Email","이메일","Email"))}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    Text(tr(lang,"Пока локальный профиль. Подключение авторизации будет следующим этапом.",
                        "현재 로컬 프로필입니다. 다음 단계에서 로그인을 연결합니다.",
                        "Local profile for now. Authentication will be connected in the next stage."), color=Color.Gray, fontSize=12.sp)
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(18.dp), color=Color.White, modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr(lang,"Поддержка KoreaTrip","KoreaTrip 지원","KoreaTrip support"), fontWeight=FontWeight.Bold, color=Navy)
                    Text(tr(lang,"Здесь появится история обращений и ответы поддержки.",
                        "문의 내역과 지원 답변이 여기에 표시됩니다.",
                        "Support tickets and replies will appear here."), color=Color.Gray)
                }
            }
        }
    }
}

private fun demoProducts() = listOf(
    CatalogItem("Samsung Galaxy", "Смартфоны • пример каталога", "Цена уточняется", "tech"),
    CatalogItem("Ноутбуки", "Работа и учёба", "Цена уточняется", "tech"),
    CatalogItem("Игровые консоли", "Консоли и аксессуары", "Цена уточняется", "tech"),
    CatalogItem("Корейский уход за кожей", "Косметика • пример каталога", "Цена уточняется", "beauty"),
    CatalogItem("Солнцезащитные средства", "Уход и защита", "Цена уточняется", "beauty")
)
private fun demoServices() = listOf(
    TravelService("Поездка под ключ", "Помощь с планированием, документами, транспортом и отелем.", "120 000 ₩ • ориентир"),
    TravelService("K-ETA / документы", "Информация и сопровождение подготовки документов. Решение принимает уполномоченный орган.", "Стоимость уточняется"),
    TravelService("Отель", "Подбор вариантов размещения по датам и бюджету.", "Стоимость уточняется"),
    TravelService("Авиабилеты и паром", "Подбор подходящего маршрута и помощь с оформлением.", "Стоимость уточняется"),
    TravelService("SIM-карта", "Подбор варианта связи для поездки по Корее.", "Стоимость уточняется"),
    TravelService("Маршрут по Корее", "Индивидуальный план по городам, интересам и срокам.", "Стоимость уточняется")
)
private fun tr(lang: Lang, ru: String, ko: String, en: String) = when(lang) { Lang.RU -> ru; Lang.KO -> ko; Lang.EN -> en }
