# KoreaTrip — native Android starter

This is a **native Kotlin + Jetpack Compose Android app**, not a WebView wrapper. It includes a multilingual UI scaffold (Russian/Korean/English), travel service catalog, product catalog (electronics and cosmetics), cart, demo orders, and a local profile screen.

## Important status
This is a functional **UI prototype**. Orders and profile data are in memory and reset when the app restarts. Product/service entries are demo data. There is no production authentication, remote database, live inventory, booking provider, payment processing, or admin dashboard connected yet. Do not present demo requests as real bookings.

## Build
- Android Studio Hedgehog or newer
- JDK 17
- Android SDK 35
- Open this folder as a Gradle project and run `app`.

For CI, use a GitHub Actions workflow with JDK 17 and Gradle 8.9; run `gradle assembleDebug bundleRelease`.

## Cloud backend plan (next milestone)
Recommended: Supabase (managed PostgreSQL + Auth + Storage + Edge Functions), because it provides hosted database/auth without operating a server.
1. Create a Supabase project.
2. Add URL and anon key via `local.properties`/CI secrets; never put the service-role key in the Android app.
3. Create tables from `backend/supabase_schema.sql`.
4. Implement Supabase Auth (email OTP/password), repository layer, and secure Row Level Security.
5. Add Edge Functions for order creation and admin-only operations.
6. Add product/service CRUD admin console (separate protected web dashboard).
7. Integrate payment provider only after orders and legal/merchant requirements are confirmed.

## Release checklist
- Add app icon and branding.
- Implement authentication, privacy policy, account deletion, and data export.
- Add remote repositories, retries, offline/error states.
- Add admin authorization and audit log.
- Test on physical devices and different screen sizes.
- Configure signed release AAB and Play Console listing.
